/*
 * Sample program that shows how to authenticate a Gen2v2 
 * tag using a preconfigured key.
 */
package samples;

import com.thingmagic.Gen2;
import com.thingmagic.Reader;
import com.thingmagic.ReaderUtil;
import com.thingmagic.SimpleReadPlan;
import com.thingmagic.TMConstants;
import com.thingmagic.TagFilter;
import com.thingmagic.TagOp;
import com.thingmagic.TagProtocol;
import com.thingmagic.TagReadData;
import com.thingmagic.TransportListener;

public class Authenticate
{
    private static Reader r = null;
    private static int[] antennaList = null;
    static BlockPermalock.SerialPrinter serialPrinter;
    static BlockPermalock.StringPrinter stringPrinter;
    static TransportListener currentListener;
    static byte[] response;
    static boolean sendRawData = true;
    static boolean _isNMV2DTag = false;

    static void usage()
    {
        System.out.printf("Usage: Please provide valid arguments, such as:\n"
                + "  (URI: 'tmr:///COM1 --ant 1,2' or 'tmr://astra-2100d3/ --ant 1,2' "
                + "or 'tmr:///dev/ttyS0 --ant 1,2')\n\n");
        System.exit(1);
    }

    public static void setTrace(Reader r, String args[])
    {
        if (args[0].toLowerCase().equals("on"))
        {
            r.addTransportListener(Reader.simpleTransportListener);
            currentListener = Reader.simpleTransportListener;
        } else if (currentListener != null)
        {
            r.removeTransportListener(Reader.simpleTransportListener);
        }
    }
    
    static  int[] parseAntennaList(String[] args,int argPosition)
    {
        int[] antennaList = null;
        try
        {
            String argument = args[argPosition + 1];
            String[] antennas = argument.split(",");
            int i = 0;
            antennaList = new int[antennas.length];
            for (String ant : antennas)
            {
                antennaList[i] = Integer.parseInt(ant);
                i++;
            }
        }
        catch (IndexOutOfBoundsException ex)
        {
            System.out.println("Missing argument after " + args[argPosition]);
            usage();
        }
        catch (Exception ex)
        {
            System.out.println("Invalid argument at position " + (argPosition + 1) + ". " + ex.getMessage());
            usage();
        }
        return antennaList;
    }
    
    public static void main(String argv[])
    {
        // Program setup   
        TagFilter target = null;
        int nextarg = 0;
        boolean trace = false;

        if (argv.length < 1 || (argv.length == 1 && argv[nextarg].equalsIgnoreCase("-v")))
        {
            usage();
        }

        if (argv[nextarg].equals("-v"))
        {
            trace = true;
            nextarg++;
        }

        // Create Reader object, connecting to physical device
        try
        {

            TagReadData[] tagReads;
            String readerURI = argv[nextarg];
            nextarg++;

            for (; nextarg < argv.length; nextarg++)
            {
                String arg = argv[nextarg];
                if (arg.equalsIgnoreCase("--ant"))
                {
                    if (antennaList != null)
                    {
                        System.out.println("Duplicate argument: --ant specified more than once");
                        usage();
                    }
                    antennaList = parseAntennaList(argv, nextarg);
                    nextarg++;
                } else
                {
                    System.out.println("Argument " + argv[nextarg] + " is not recognised");
                    usage();
                }
            }

            r = Reader.create(readerURI);
            if (trace)
            {
                setTrace(r, new String[]
                {
                    "on"
                });
            }
            r.connect();
            
            if (Reader.Region.UNSPEC == (Reader.Region) r.paramGet("/reader/region/id")) 
            {
                Reader.Region[] supportedRegions = (Reader.Region[]) r.paramGet(TMConstants.TMR_PARAM_REGION_SUPPORTEDREGIONS);
                if (supportedRegions.length < 1) 
                {
                    throw new Exception("Reader doesn't support any regions");
                } 
                else 
                {
                    r.paramSet("/reader/region/id", supportedRegions[0]);
                }
            }

            /**
             * Checking the software version of Sargas.
             * Antenna detection is supported on Sargas from the software versions higher than 5.1.x.x.
             * User has to pass antenna as an argument, if the antenna detection is not supported on
             * the respective reader firmware.
             */
            String model = r.paramGet("/reader/version/model").toString();
            Boolean checkPort = (Boolean)r.paramGet(TMConstants.TMR_PARAM_ANTENNA_CHECKPORT);
            String swVersion = (String) r.paramGet(TMConstants.TMR_PARAM_VERSION_SOFTWARE);
            if ((model.equalsIgnoreCase("M6e Micro") || model.equalsIgnoreCase("M6e Nano") ||
                (model.equalsIgnoreCase("Sargas") && (swVersion.startsWith("5.1")))) && (false == checkPort) && antennaList == null)
            {
                System.out.println("Module doesn't has antenna detection support, please provide antenna list");
                r.destroy();
                usage();
            }

            r.paramSet("/reader/tagop/antenna", antennaList[0]);

            byte[]  key0  =  new byte[]{(byte)0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF, (byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xAB, (byte) 0xCD, (byte) 0xEF};
            byte[]  key1  =  new byte[]{(byte)0x11, (byte)0x22, (byte) 0x33, (byte) 0x44, (byte) 0x55, (byte) 0x66, (byte) 0x77, (byte) 0x88, (byte) 0x11, (byte) 0x22, (byte) 0x33, (byte) 0x44, (byte) 0x55, (byte) 0x66, (byte) 0x77, (byte) 0x88};
            byte[] ichallenge = new byte[]{(byte) 0x01, (byte) 0x23, (byte) 0x45, (byte) 0x67, (byte) 0x89, (byte) 0xab, (byte) 0xcd, (byte) 0xef, (byte) 0xab, (byte) 0xcd};
            
            Gen2.NXP.AES.Tam1Authentication tam1Auth;
            Gen2.NXP.AES.Tam2Authentication tam2Auth;
            int protMode;

            // Uncomment this to enable select filter
            //target = new Gen2.Select(false, Gen2.Bank.EPC, 32, 16, new byte[] {(byte)0x11,(byte)0x22});

            // Uncomment this to enable TAM1 Authentication with KEY0 for NXPUCODE AES Tag
            tam1Auth = new Gen2.NXP.AES.Tam1Authentication(Gen2.NXP.AES.KeyId.KEY0, key0, ichallenge, sendRawData);
            Gen2.Authenticate tam1AuthKey0 = new Gen2.NXP.AES.Authenticate(tam1Auth);
            System.out.println(tam1AuthKey0.toString());
            response = (byte[])r.executeTagOp(tam1AuthKey0, null);

            if(sendRawData)
            {
                byte[] challenge = decryptIchallenge(key0,response, true);
                System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
            }

            //Uncomment this to enable TAM1 Authentication with KEY1
            /*tam1Auth = new Gen2.NXP.AES.Tam1Authentication(Gen2.NXP.AES.KeyId.KEY1, key1, ichallenge, sendRawData);
            Gen2.Authenticate tam1AuthKey1 = new Gen2.NXP.AES.Authenticate(tam1Auth);
            System.out.println(tam1AuthKey1.toString());
            response = (byte[])r.executeTagOp(tam1AuthKey1, null);

            if(sendRawData)
            {
                byte[] challenge = decryptIchallenge(key1,response,true);
                System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
            }*/

            //Uncomment this to enable TAM2 Authentication with KEY1
            // supported protMode value is 1 for NXPUCODE AES
            /*protMode = 1;
            tam2Auth = new Gen2.NXP.AES.Tam2Authentication(Gen2.NXP.AES.KeyId.KEY1,key1, ichallenge, Gen2.NXP.AES.Profile.EPC, 0, 1, protMode, sendRawData);
            Gen2.Authenticate tam2AuthKey1 = new Gen2.NXP.AES.Authenticate(tam2Auth);
            System.out.println(tam2AuthKey1.toString());
            response = (byte[])r.executeTagOp(tam2AuthKey1, null);
            if(sendRawData)
            {
                byte[] cipherData = new byte[16];
                byte[] IV = new byte[16];
                System.arraycopy(response, 0, IV, 0, 16);
                System.arraycopy(response, 16, cipherData, 0, 16);
                String customData = decryptCustomData(key1, cipherData, IV.clone());
                System.out.println("customData :"+customData);
                byte[] challenge = decryptIchallenge(key1, IV, true);
                System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
            } 
            else
            {
                System.out.println("Data :"+ ReaderUtil.byteArrayToHexString(response));
            }*/
            
            /* Embedded tag operations */
            {
                // Uncomment this to execute embedded tagop for TAM1 Authentication with KEY0 
                /*tam1Auth = new Gen2.NXP.AES.Tam1Authentication(Gen2.NXP.AES.KeyId.KEY0, key0, ichallenge, sendRawData);
                Gen2.Authenticate embeddedTam1AuthKey0 = new Gen2.NXP.AES.Authenticate(tam1Auth);
                System.out.println("Embedded Tag operation of " + embeddedTam1AuthKey0.toString());
                response = performEmbeddedOperation(null, embeddedTam1AuthKey0);

                if(sendRawData)
                {
                    byte[] challenge = decryptIchallenge(key0,response, true);
                    System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
                }*/

                //Uncomment this to execute embedded tagop for TAM1 Authentication with KEY1
                /*tam1Auth = new Gen2.NXP.AES.Tam1Authentication(Gen2.NXP.AES.KeyId.KEY1, key1, ichallenge, sendRawData);
                Gen2.Authenticate embeddedTam1AuthKey1 = new Gen2.NXP.AES.Authenticate(tam1Auth);
                System.out.println("Embedded Tag operation of " + embeddedTam1AuthKey1.toString());
                response = performEmbeddedOperation(null, embeddedTam1AuthKey1);

                if(sendRawData)
                {
                    byte[] challenge = decryptIchallenge(key1,response,true);
                    System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
                }*/

                //Uncomment this to execute embedded tagop for TAM2 Authentication with KEY1
                // supported protMode value is 1 for NXPUCODE DNA
                /*protMode = 1;
                tam2Auth = new Gen2.NXP.AES.Tam2Authentication(Gen2.NXP.AES.KeyId.KEY1,key1, ichallenge, Gen2.NXP.AES.Profile.EPC, 0, 1, protMode, sendRawData);
                Gen2.Authenticate embeddedTam2AuthKey1 = new Gen2.NXP.AES.Authenticate(tam2Auth);
                System.out.println("Embedded Tag operation of " + embeddedTam2AuthKey1.toString());
                response = performEmbeddedOperation(null, embeddedTam2AuthKey1);
                if(sendRawData)
                {
                    byte[] cipherData = new byte[16];
                    byte[] IV = new byte[16];
                    System.arraycopy(response, 0, IV, 0, 16);
                    System.arraycopy(response, 16, cipherData, 0, 16);
                    String customData = decryptCustomData(key1, cipherData, IV.clone());
                    System.out.println("customData :"+customData);
                    byte[] challenge = decryptIchallenge(key1, IV, true);
                    System.out.println("Returned Ichallenge :"+ ReaderUtil.byteArrayToHexString(challenge));
                } 
                else
                {
                    System.out.println("Data :"+ ReaderUtil.byteArrayToHexString(response));
                }*/
            }
            //Enable flag _isNMV2DTag for TAM1/TAM2 Authentication with KEY0 for NMV2D Tag
            if (_isNMV2DTag) 
            {
                // NMV2D tag only supports KEY0
                // TAM1 Authentication with KEY0
                byte[] key0_NMV2D = new byte[]{(byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00};
                //Uncomment this to enable TAM1 with key0
                /*tam1Auth = new Gen2.NXP.AES.Tam1Authentication(Gen2.NXP.AES.KeyId.KEY0, key0_NMV2D, ichallenge, sendRawData);
                 Gen2.Authenticate tam1AuthKey0 = new Gen2.NXP.AES.Authenticate(tam1Auth);
                 System.out.println(tam1AuthKey0.toString());
                 response = (byte[]) r.executeTagOp(tam1AuthKey0, null);
                 if (sendRawData) {
                 byte[] challenge = decryptIchallenge(key0_NMV2D, response, true);
                 System.out.println("Returned Ichallenge :" + ReaderUtil.byteArrayToHexString(challenge));
                 }*/

                //TAM2 Authentication with KEY0
                //supported protMode values are 0,1,2,3
                protMode = 0;
                tam2Auth = new Gen2.NXP.AES.Tam2Authentication(Gen2.NXP.AES.KeyId.KEY0, key0_NMV2D, ichallenge, Gen2.NXP.AES.Profile.EPC, 0, 1, protMode, sendRawData);
                Gen2.Authenticate tam2AuthKey0 = new Gen2.NXP.AES.Authenticate(tam2Auth);
                System.out.println(tam2AuthKey0.toString());
                response = (byte[]) r.executeTagOp(tam2AuthKey0, null);
                if (sendRawData) {
                    byte[] cipherData = new byte[16];
                    byte[] IV = new byte[16];
                    System.arraycopy(response, 0, IV, 0, 16);
                    System.arraycopy(response, 16, cipherData, 0, 16);
                    if (protMode == 1 || protMode == 3) {
                        String customData = decryptCustomData(key0_NMV2D, cipherData, IV.clone());
                        System.out.println("customData :" + customData);
                    } else {
                        System.out.println("customData :" + ReaderUtil.byteArrayToHexString(cipherData));
                    }
                    byte[] challenge = decryptIchallenge(key0_NMV2D, IV, true);
                    System.out.println("Returned Ichallenge :" + ReaderUtil.byteArrayToHexString(challenge));
                } else {
                    System.out.println("Data :" + ReaderUtil.byteArrayToHexString(response));
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static byte[] decryptIchallenge(byte[] key, byte[] response, boolean resize) throws Exception
    {
        byte[] decryperText = AES.decrypt(key, response);
        if(resize)
            return  resizeArray(decryperText.clone());
        return  decryperText;
    }

    public static String decryptCustomData(byte[] key, byte[] cipherData, byte[] IV) throws Exception
    {
        byte[] decipheredText = new byte[16];
        decipheredText = decryptIchallenge(key,cipherData,false);
        byte[] CustomData = new byte[16];
        for (int i = 0; i < IV.length; i++)
        {
            CustomData[i] = (byte)(decipheredText[i] ^ IV[i]);
        }
        return ReaderUtil.byteArrayToHexString(CustomData);
    }

    public static byte[] resizeArray(byte[] arrayToResize) 
    {
        int newCapacity = arrayToResize.length-6;
        byte[] newArray = new byte[newCapacity];
        System.arraycopy(arrayToResize, 6,newArray, 0, newCapacity);
        return newArray;
    }
    
    public static byte[] performEmbeddedOperation(TagFilter filter, TagOp op) throws Exception
    {
        TagReadData[] tagReads = null;
        byte[] response = null;
        SimpleReadPlan plan = new SimpleReadPlan(antennaList, TagProtocol.GEN2, filter, op, 1000);
        r.paramSet("/reader/read/plan", plan);
        tagReads = r.read(1000);
        for (TagReadData tr : tagReads)
        {
            response = tr.getData();
        }
        return response;
    }
}